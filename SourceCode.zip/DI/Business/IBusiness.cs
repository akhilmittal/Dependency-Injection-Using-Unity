﻿namespace Business
{
  public interface IBusiness
  {
    string GetBusinessData();
  }
}
