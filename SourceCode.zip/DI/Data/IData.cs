﻿namespace Data
{
  public interface IData
  {
    string GetData();
  }
}
